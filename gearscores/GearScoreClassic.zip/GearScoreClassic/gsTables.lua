﻿	rsTable = {
		[1] = {
			["ilvl"] = 78,
			["name"] = "Molten Core",
			["softCap"] = 5,
			["hardCap"] = 10,
			["totalWeight"] = 1,
			["bosses"] = {
				[1] = {
					["id"] = 1099,
					["id2"] = 0,
					["name"] = "Ragnaros",
					["weight"] = 1
				}
			}
		},
		[2] = {
			["ilvl"] = 83,
			["name"] = "Blackwing Lair",
			["softCap"] = 5,
			["hardCap"] = 10,
			["totalWeight"] = 1,
			["bosses"] = {
				[1] = {
					["id"] = 1100,
					["id2"] = 0,
					["name"] = "Nefarian",
					["weight"] = 1
				}
			}
		},
		[3] = {
			["ilvl"] = 88,
			["name"] = "Temple of Ahn'Qiraj",
			["softCap"] = 5,
			["hardCap"] = 10,
			["totalWeight"] = 1,
			["bosses"] = {
				[1] = {
					["id"] = 1101,
					["id2"] = 0,
					["name"] = "C'Thun",
					["weight"] = 1
				}
			}
		},
		[4] = {
			["ilvl"] = 125,
			["name"] = "Karazhan/Gruul/Magtheridon",
			["softCap"] = 5,
			["hardCap"] = 10,
			["totalWeight"] = 3,
			["bosses"] = {
				[1] = {
					["id"] = 1083,
					["id2"] = 0,
					["name"] = "Prince Malchezaar",
					["weight"] = 1
				},
				[2] = {
					["id"] = 1085,
					["id2"] = 0,
					["name"] = "Gruul",
					["weight"] = 1
				},
				[3] = {
					["id"] = 1086,
					["id2"] = 0,
					["name"] = "Magtheridon",
					["weight"] = 1
				}
			}
		},
		[5] = {
			["ilvl"] = 138,
			["name"] = "ZA/SSC/TK",
			["softCap"] = 5,
			["hardCap"] = 10,
			["totalWeight"] = 3,
			["bosses"] = {
				[1] = {
					["id"] = 1084,
					["id2"] = 0,
					["name"] = "Zul'jin",
					["weight"] = 1
				},
				[2] = {
					["id"] = 1087,
					["id2"] = 0,
					["name"] = "Lady Vashj",
					["weight"] = 1
				},
				[3] = {
					["id"] = 1088,
					["id2"] = 0,
					["name"] = "Kael'thas",
					["weight"] = 1
				}
			}
		},
		[6] = {
			["ilvl"] = 164,
			["name"] = "BT/Sunwell",
			["softCap"] = 5,
			["hardCap"] = 10,
			["totalWeight"] = 2,
			["bosses"] = {
				[1] = {
					["id"] = 1089,
					["id2"] = 0,
					["name"] = "Illidan Stormrage",
					["weight"] = 1
				},
				[2] = {
					["id"] = 1090,
					["id2"] = 0,
					["name"] = "Kil'jaeden",
					["weight"] = 1
				}
			}
		},
		[7] = {
			["ilvl"] = 226,
			["name"] = "Naxx/OS/Maly/Arch",
			["softCap"] = 5,
			["hardCap"] = 10,
			["totalWeight"] = 28.2,
			["bosses"] = {
				[1] = {
					["id"] = 1361,
					["id2"] = 1368,
					["name"] = "Anub'Rekhan",
					["weight"] = 1
				},
				[2] = {
					["id"] = 1362,
					["id2"] = 1380,
					["name"] = "Grand Widow Faerlina",
					["weight"] = 1
				},
				[3] = {
					["id"] = 1363,
					["id2"] = 1386,
					["name"] = "Maexxna",
					["weight"] = 2
				},
				[4] = {
					["id"] = 1364,
					["id2"] = 1367,
					["name"] = "Patchwerk",
					["weight"] = 1
				},
				[5] = {
					["id"] = 1365,
					["id2"] = 1387,
					["name"] = "Noth the Plaguebringer",
					["weight"] = 1
				},
				[6] = {
					["id"] = 1366,
					["id2"] = 1379,
					["name"] = "Gothik the Harvester",
					["weight"] = 1
				},
				[7] = {
					["id"] = 1369,
					["id2"] = 1382,
					["name"] = "Heigan the Unclean",
					["weight"] = 1
				},
				[8] = {
					["id"] = 1370,
					["id2"] = 1385,
					["name"] = "Loatheb",
					["weight"] = 2
				},
				[9] = {
					["id"] = 1371,
					["id2"] = 1381,
					["name"] = "Grobbulus",
					["weight"] = 1
				},
				[10] = {
					["id"] = 1372,
					["id2"] = 1378,
					["name"] = "Gluth",
					["weight"] = 1
				},
				[11] = {
					["id"] = 1373,
					["id2"] = 1388,
					["name"] = "Thaddius",
					["weight"] = 2
				},
				[12] = {
					["id"] = 1374,
					["id2"] = 1384,
					["name"] = "Instructor Razuvious",
					["weight"] = 1
				},
				[13] = {
					["id"] = 1375,
					["id2"] = 1383,
					["name"] = "Four Horsemen",
					["weight"] = 2
				},
				[14] = {
					["id"] = 1376,
					["id2"] = 1389,
					["name"] = "Sapphiron",
					["weight"] = 3
				},
				[15] = {
					["id"] = 1377,
					["id2"] = 1390,
					["name"] = "Kel'Thuzad",
					["weight"] = 3
				},
				[16] = {
					["id"] = 1392,
					["id2"] = 1393,
					["name"] = "Sartharion",
					["weight"] = 2
				},
				[17] = {
					["id"] = 1753,
					["id2"] = 1754,
					["name"] = "Archavon the Stone Watcher",
					["weight"] = .2
				},
				[18] = {
					["id"] = 1391,
					["id2"] = 1394,
					["name"] = "Malygos",
					["weight"] = 3
				}
			}
		},
		[8] = {
			["ilvl"] = 232,
			["name"] = "Ulduar/Emalon",
			["softCap"] = 5,
			["hardCap"] = 10,
			["totalWeight"] = 22.2,
			["bosses"] = {
				[1] = {
					["id"] = 2856,
					["id2"] = 2872,
					["name"] = "Flame Leviathan",
					["weight"] = 1
				},
				[2] = {
					["id"] = 2857,
					["id2"] = 2873,
					["name"] = "Razorscale",
					["weight"] = 1
				},
				[3] = {
					["id"] = 2858,
					["id2"] = 2874,
					["name"] = "Ignis the Furnace Master",
					["weight"] = 1
				},
				[4] = {
					["id"] = 2859,
					["id2"] = 2884,
					["name"] = "XT-002 Deconstructor",
					["weight"] = 1
				},
				[5] = {
					["id"] = 2860,
					["id2"] = 2885,
					["name"] = "Assembly of Iron",
					["weight"] = 1
				},
				[6] = {
					["id"] = 2861,
					["id2"] = 2875,
					["name"] = "Kologarn",
					["weight"] = 1
				},
				[7] = {
					["id"] = 2862,
					["id2"] = 3256,
					["name"] = "Hodir",
					["weight"] = 2
				},
				[8] = {
					["id"] = 2863,
					["id2"] = 3257,
					["name"] = "Thorim",
					["weight"] = 2
				},
				[9] = {
					["id"] = 2864,
					["id2"] = 3258,
					["name"] = "Freya",
					["weight"] = 2
				},
				[10] = {
					["id"] = 2865,
					["id2"] = 2879,
					["name"] = "Mimiron",
					["weight"] = 2
				},
				[11] = {
					["id"] = 2866,
					["id2"] = 2880,
					["name"] = "General Vezax",
					["weight"] = 2
				},
				[12] = {
					["id"] = 2867,
					["id2"] = 2881,
					["name"] = "Algalon the Observer",
					["weight"] = 3
				},
				[13] = {
					["id"] = 2868,
					["id2"] = 2882,
					["name"] = "Auriaya",
					["weight"] = 1
				},
				[14] = {
					["id"] = 2869,
					["id2"] = 2883,
					["name"] = "Yogg-Saron",
					["weight"] = 3
				},
				[15] = {
					["id"] = 2870,
					["id2"] = 3236,
					["name"] = "Emalon the Storm Watcher",
					["weight"] = .2
				}
			}
		},
		[9] = {
			["ilvl"] = 258,
			["name"] = "TotC/ToGC/Koralon",
			["softCap"] = 5,
			["hardCap"] = 10,
			["totalWeight"] = 16.2,
			["bosses"] = {
				[1] = {
					["id"] = 4028,
					["id2"] = 4031,
					["name"] = "Beasts of Northrend",
					["weight"] = 1
				},
				[2] = {
					["id"] = 4032,
					["id2"] = 4034,
					["name"] = "Lord Jaraxxus",
					["weight"] = 1
				},
				[3] = {
					["id"] = 4036,
					["id2"] = 4038,
					["name"] = "Faction Champions",
					["weight"] = 1
				},
				[4] = {
					["id"] = 4040,
					["id2"] = 4042,
					["name"] = "Val'kyr Twins",
					["weight"] = 1
				},
				[5] = {
					["id"] = 4044,
					["id2"] = 4046,
					["name"] = "Anub'arak",
					["weight"] = 1
				},
				[6] = {
					["id"] = 4030,
					["id2"] = 4029,
					["name"] = "Beasts of Northrend",
					["weight"] = 2
				},
				[7] = {
					["id"] = 4033,
					["id2"] = 4035,
					["name"] = "Lord Jaraxxus",
					["weight"] = 2
				},
				[8] = {
					["id"] = 4037,
					["id2"] = 4039,
					["name"] = "Faction Champions",
					["weight"] = 2
				},
				[9] = {
					["id"] = 4041,
					["id2"] = 4043,
					["name"] = "Val'kyr Twins",
					["weight"] = 2
				},
				[10] = {
					["id"] = 4045,
					["id2"] = 4047,
					["name"] = "Anub'arak",
					["weight"] = 3
				},
				[11] = {
					["id"] = 4074,
					["id2"] = 4075,
					["name"] = "Koralon the Flame Watcher",
					["weight"] = .2
				}
			}
		},
		[10] = {
			["ilvl"] = 277,
			["name"] = "ICC/HICC/RS/Toravon",
			["softCap"] = 5,
			["hardCap"] = 10,
			["totalWeight"] = 68.2,
			["bosses"] = {
				[1] = {
					["id"] = 4639,
					["id2"] = 4641,
					["name"] = "Lord Marrowgar",
					["weight"] = 1
				},
				[2] = {
					["id"] = 4643,
					["id2"] = 4655,
					["name"] = "Lady Deathwhisper",
					["weight"] = 1
				},
				[3] = {
					["id"] = 4644,
					["id2"] = 4660,
					["name"] = "Gunship Battle",
					["weight"] = 1
				},
				[4] = {
					["id"] = 4645,
					["id2"] = 4663,
					["name"] = "Deathbringer",
					["weight"] = 1
				},
				[5] = {
					["id"] = 4646,
					["id2"] = 4666,
					["name"] = "Festergut",
					["weight"] = 2
				},
				[6] = {
					["id"] = 4647,
					["id2"] = 4669,
					["name"] = "Rotface",
					["weight"] = 2
				},
				[7] = {
					["id"] = 4648,
					["id2"] = 4672,
					["name"] = "Blood Prince Council",
					["weight"] = 2
				},
				[8] = {
					["id"] = 4649,
					["id2"] = 4675,
					["name"] = "Valithria Dreamwalker",
					["weight"] = 2
				},
				[9] = {
					["id"] = 4650,
					["id2"] = 4678,
					["name"] = "Professor Putricide",
					["weight"] = 2
				},
				[10] = {
					["id"] = 4651,
					["id2"] = 4681,
					["name"] = "Blood Queen Lana'thel",
					["weight"] = 2
				},
				[11] = {
					["id"] = 4652,
					["id2"] = 4683,
					["name"] = "Sindragosa",
					["weight"] = 3
				},
				[12] = {
					["id"] = 4653,
					["id2"] = 4687,
					["name"] = "Lich King",
					["weight"] = 4
				},
				[13] = {
					["id"] = 4640,
					["id2"] = 4642,
					["name"] = "Lord Marrowgar",
					["weight"] = 2
				},
				[14] = {
					["id"] = 4654,
					["id2"] = 4656,
					["name"] = "Lady Deathwhisper",
					["weight"] = 2
				},
				[15] = {
					["id"] = 4659,
					["id2"] = 4661,
					["name"] = "Gunship Battle",
					["weight"] = 2
				},
				[16] = {
					["id"] = 4662,
					["id2"] = 4664,
					["name"] = "Deathbringer",
					["weight"] = 2
				},
				[17] = {
					["id"] = 4665,
					["id2"] = 4667,
					["name"] = "Festergut",
					["weight"] = 3
				},
				[18] = {
					["id"] = 4668,
					["id2"] = 4670,
					["name"] = "Rotface",
					["weight"] = 3
				},
				[19] = {
					["id"] = 4671,
					["id2"] = 4673,
					["name"] = "Blood Prince Council",
					["weight"] = 3
				},
				[20] = {
					["id"] = 4674,
					["id2"] = 4676,
					["name"] = "Valithria Dreamwalker",
					["weight"] = 3
				},
				[21] = {
					["id"] = 4677,
					["id2"] = 4679,
					["name"] = "Professor Putricide",
					["weight"] = 3
				},
				[22] = {
					["id"] = 4680,
					["id2"] = 4682,
					["name"] = "Blood Queen Lana'thel",
					["weight"] = 3
				},
				[23] = {
					["id"] = 4684,
					["id2"] = 4685,
					["name"] = "Sindragosa",
					["weight"] = 4
				},
				[24] = {
					["id"] = 4686,
					["id2"] = 4688,
					["name"] = "Lich King",
					["weight"] = 5
				},
				[25] = {
					["id"] = 4657,
					["id2"] = 4658,
					["name"] = "Toravon the Ice Watcher",
					["weight"] = .2
				},
				[26] = {
					["id"] = 4821,
					["id2"] = 4820,
					["name"] = "Halion",
					["weight"] = 5
				},
				[27] = {
					["id"] = 4822,
					["id2"] = 4823,
					["name"] = "Halion",
					["weight"] = 5
				}
			}
		}
	}


	gsColor = {
		[0] = { ["GS"] = 0, ["R"] = 140, ["G"] = 140, ["B"] = 140 },
		[1] = { ["GS"] = 1000, ["R"] = 255, ["G"] = 255, ["B"] = 255 },
		[2] = { ["GS"] = 2000, ["R"] = 30, ["G"] = 255, ["B"] = 0 },
		[3] = { ["GS"] = 3000, ["R"] = 0, ["G"] = 127, ["B"] = 255 },
		[4] = { ["GS"] = 4000, ["R"] = 176, ["G"] = 71, ["B"] = 247 },
		[5] = { ["GS"] = 5000, ["R"] = 240, ["G"] = 120, ["B"] = 0 },
		[6] = { ["GS"] = 6000, ["R"] = 255, ["G"] = 0, ["B"] = 0 },
	}
	charSlot = {
		[1] = 1 , --head
		[2] = 0.5625 , --neck
		[3] = 0.75 , --shoulder
		[4] = 0 , --shirt
		[5] = 1 , --chest
		[6] = 0.75 , --waist
		[7] = 1 , --legs
		[8] = 0.75 , --feet
		[9] = 0.5625 , --wrist
		[10] = 0.75 , --hands
		[11] = 0.5625 , --finger1
		[12] = 0.5625 , --finger2
		[13] = 0.5625 , --trinket1
		[14] = 0.5625 , --trinket2
		[15] = 0.5625 , --back
		[16] = 2 , --main-hand
		[17] = 1 , --off-hand
		[18] = 0.3164 , --ranged
		[19] = 0  --tabard
	}
	gsFormula = {
		["A"] = {
			[4] = { ["A"] = 91.45, ["B"] = 0.65 },
			[3] = { ["A"] = 81.375, ["B"] = 0.8125 },
			[2] = { ["A"] = 73, ["B"] = 1 }
		},
		["B"] = {
			[4] = { ["A"] = 26, ["B"] = 1.2 },
			[3] = { ["A"] = 0.75, ["B"] = 1.8 },
			[2] = { ["A"] = 8, ["B"] = 2 },
			[1] = { ["A"] = 0, ["B"] = 2.25 }
		}
	}
	
	itemSlotTable = {
		["INVTYPE_HEAD"] = { ["slot"] = 1 },
		["INVTYPE_NECK"] = { ["slot"] = 2 },
		["INVTYPE_SHOULDER"] = { ["slot"] = 3 },
		["INVTYPE_BODY"] = { ["slot"] = 4 },
		["INVTYPE_CHEST"] = { ["slot"] = 5 },
		["INVTYPE_ROBE"] = { ["slot"] = 5 },
		["INVTYPE_WAIST"] = { ["slot"] = 6 },
		["INVTYPE_LEGS"] = { ["slot"] = 7 },
		["INVTYPE_FEET"] = { ["slot"] = 8 },
		["INVTYPE_WRIST"] = { ["slot"] = 9 },
		["INVTYPE_HAND"] = { ["slot"] = 10 },
		["INVTYPE_FINGER"] = { ["slot"] = 11 },
		["INVTYPE_TRINKET"] = { ["slot"] = 13 },
		["INVTYPE_CLOAK"] = { ["slot"] = 15 },
		["INVTYPE_WEAPON"] = { ["slot"] = 16 },
		["INVTYPE_SHIELD"] = { ["slot"] = 17 },
		["INVTYPE_2HWEAPON"] = { ["slot"] = 16 },
		["INVTYPE_WEAPONMAINHAND"] = { ["slot"] = 16 },
		["INVTYPE_WEAPONOFFHAND"] = { ["slot"] = 17 },
		["INVTYPE_HOLDABLE"] = { ["slot"] = 17 },
		["INVTYPE_RANGED"] = { ["slot"] = 18 },
		["INVTYPE_THROWN"] = { ["slot"] = 18 },
		["INVTYPE_RANGEDRIGHT"] = { ["slot"] = 18 },
		["INVTYPE_RELIC"] = { ["slot"] = 18 }
	}