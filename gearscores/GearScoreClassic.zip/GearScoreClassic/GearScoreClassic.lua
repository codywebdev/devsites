﻿local frame = CreateFrame("FRAME", "gsframe");
frame:RegisterEvent("PLAYER_REGEN_DISABLED");
frame:RegisterEvent("PLAYER_REGEN_ENABLED");

--Prevent addon from running while in combat
local function enterCombat(self, event, ...)
	if (event == "PLAYER_REGEN_DISABLED") then playerInCombat = true; end
	if (event == "PLAYER_REGEN_ENABLED") then playerInCombat = false; end
	if (event == "INSPECT_ACHIEVEMENT_READY") then showTooltipRaidScore(); end
end
frame:SetScript("OnEvent", enterCombat);

local raidScoreCount = 0
local tooltipCleared = true
local lastQueryTime = 0

----Calculate raidScore and return it
function getRaidScore()
	local raidScore, softScore, id1, id2, tierGS, tierIlvl, tierScore, hardScore = 0,0,0,0,0,0,0,0
	
	for i=1, 10 do
		tierIlvl = rsTable[i]["ilvl"]
		if (tierIlvl <= 120) then
			tierGS = floor((((tierIlvl - 26) / 1.2) * 12.2539 * 1.8618)-8)
		else
			tierGS = floor((((tierIlvl - 91.45) / .65) * 12.2539 * 1.8618)-8)
		end
		
		for j=1, table.getn(rsTable[i]["bosses"]) do
			id1 = GetComparisonStatistic(rsTable[i]["bosses"][j]["id"])  --rsTableExample[i]["bosses"][j]["id"]
			if (rsTable[i]["bosses"][j]["id2"] > 0) then 
				id2 = GetComparisonStatistic(rsTable[i]["bosses"][j]["id2"])  --rsTableExample[i]["bosses"][j]["id2"]
			else
				id2 = 0;
			end
			if (id1 == "--") then id1 = 0 end
			if (id2 == "--") then id2 = 0 end
			softScore = softScore + min((id1+id2),rsTable[i]["softCap"])*(rsTable[i]["bosses"][j]["weight"])  --get each bosses softscore and add them together
			hardScore = hardScore + floor(max(min((id1+id2-rsTable[i]["softCap"]), (rsTable[i]["hardCap"]-rsTable[i]["softCap"])),0)*rsTable[i]["bosses"][j]["weight"])
		end
		
		softScore = min(softScore,(rsTable[i]["softCap"]*rsTable[i]["totalWeight"]))  --make sure the total softscore doesn't go over the cap
		
		if (raidScore < (tierGS*2)/3) then --first 4 weighted kills in a tier account for approx 2/3 of the maximum raidScore (if you're capable of doing the content, then your RS should go up fast)
			raidScore = floor(max(raidScore,floor( ((tierGS*2*min(softScore,4))/12) )))
		end
		
		softScore = softScore / rsTable[i]["totalWeight"]  --get average number of weighted kills up to the softCap
		
		
		tierScore = tierGS - raidScore  --what is the maximum amount we can add to meet softcap
		if (tierScore < 0) then tierScore = 0 end
		tierScore = floor(tierScore * (softScore/rsTable[i]["softCap"])) --figure up how much of the raidscore this tier gets
		
			
		raidScore = raidScore + tierScore + hardScore
				
		softScore, id1, id2, tierScore, hardScore = 0,0,0,0,0
	end
	
		
	return raidScore
end

----Show raidScore on tooltip
function showTooltipRaidScore()
	if (raidScoreCount == 1) then
		frame:UnregisterEvent("INSPECT_ACHIEVEMENT_READY");
		local raidScore = getRaidScore()
		GameTooltip:AddLine("RaidScore: "..raidScore, getGSColor(raidScore))
		GameTooltip:Show();
	end
	
	if (not UnitIsPlayer("mouseover")) then
		GameTooltip:FadeOut()
	end
	
	tooltipCleared = false
	ClearAchievementComparisonUnit()
	raidScoreCount = raidScoreCount - 1
end


--returns the gearScore of an item
function getItemGS(iLevel, iRarity, iSlot) 
	local qualityScale = 1
	
	if (iRarity == 5) then qualityScale = 1.3 --legendaries get scale of 1.3
	end
	
	--adjust gear quality to uncommon, rare, epic for calculation purposes
	local gsTable = "A"
	local adjQuality = iRarity
	
	if (adjQuality == 5) then 
		adjQuality = 4
	elseif (adjQuality == 7 or adjQuality == 6) then 
		adjQuality = 3
		iLevel = 187.05 --heirloom items are ilvl 187.05
	end
	
	--use the second table if ilvl is less than or equal to 120
	if (iLevel <= 120) then
		gsTable = "B"
		if (adjQuality == 0 or adjQuality == 1) then
			adjQuality = 1
			qualityScale = 0.005
		elseif (adjQuality ~= 1 and adjQuality ~= 2 and adjQuality ~= 3 and adjQuality ~= 4) then 
			adjQuality = 4 --prevent division by zero error when no item is present
		end
		
	--use the first table if ilvl is greater than 120
	else
		if (adjQuality == 0 or adjQuality == 0) then 
			adjQuality = 2
			qualityScale = 0.005
		elseif (adjQuality ~= 2 and adjQuality ~= 3 and adjQuality ~= 4) then 
			adjQuality = 4 --prevent division by zero error when no item is present
		end
	end 
	
	local gearscore = floor(((iLevel - gsFormula[gsTable][adjQuality]["A"]) / gsFormula[gsTable][adjQuality]["B"]) * charSlot[iSlot] * 1.8618 * qualityScale)
	
	return max(0, gearscore)
	
end


--Calculate gearScore color and return it
function getGSColor(gearscore)

	local gsColor1, gsColor2
	
	for i=0, 6 do
		if (gearscore <= gsColor[i]["GS"]) then
			if (i==0) then
				gsColor1 = gsColor[i]
				gsColor2 = gsColor[(i+1)]
				break
			else 
				gsColor1 = gsColor[(i-1)]
				gsColor2 = gsColor[i]
				break
			end
		else
			gsColor1 = gsColor[6]
			gsColor2 = gsColor[6]
		end
	end
	
	local redDecValue = ((((gsColor2["R"] - gsColor1["R"]) / (gsColor2["GS"] - gsColor1["GS"])) * (gearscore - gsColor1["GS"])) + gsColor1["R"]);
	local greenDecValue = ((((gsColor2["G"] - gsColor1["G"]) / (gsColor2["GS"] - gsColor1["GS"])) * (gearscore - gsColor1["GS"])) + gsColor1["G"]);
	local blueDecValue = ((((gsColor2["B"] - gsColor1["B"]) / (gsColor2["GS"] - gsColor1["GS"])) * (gearscore - gsColor1["GS"])) + gsColor1["B"]);

	if (gearscore >= gsColor[6]["GS"]) then
		return (gsColor[6]["R"]/255), (gsColor[6]["G"]/255), (gsColor[6]["B"]/255)
	else
		return (redDecValue/255), (greenDecValue/255), (blueDecValue/255)
	end
end


----Show unit gearScore on the tooltip
function showTooltipGS()
	if (playerInCombat or not UnitIsPlayer("mouseover") or not CanInspect("mouseover")) then return; end;
	
	local gearScore = 0;
	local weaponGS = 0;
	local totalItems = 0;
	
	NotifyInspect("mouseover");
	
	for i = 1, 18 do
		if (i == 4) then 
			iLink = nil
		else 
			iLink = GetInventoryItemLink("mouseover", i)
		end
		
		if (iLink ~= nil) then 
			local iName, iLink, iRarity, iLevel, iMinLevel, iType, iSubType, iStackCount, iEquipLocation, iTexture, iSellPrice= GetItemInfo(iLink)
			if (i == 16) then
				if (iEquipLocation == "INVTYPE_WEAPON" or iEquipLocation == "INVTYPE_WEAPONMAINHAND") then --if 1 handed weapon, then divide by 2
					weaponGS = floor(getItemGS(iLevel, iRarity, i)/2)
				elseif (GetInventoryItemLink("mouseover", 17) ~= nil) then --if titangrip then divide by two
					weaponGS = floor(getItemGS(iLevel, iRarity, i)/2)
				else
					weaponGS = getItemGS(iLevel, iRarity, i) --2 handed and nothing in off hand
				end
			elseif (i == 17) then
				weaponGS = weaponGS + getItemGS(iLevel, iRarity, i)
			elseif (i == 18 and UnitClass("mouseover") == "Hunter") then
				weaponGS = floor(weaponGS * 0.3164)
				weaponGS = weaponGS + floor(getItemGS(iLevel, iRarity, i)*5.3224)
			else
				gearScore = gearScore + getItemGS(iLevel, iRarity, i)
			end
		end
	end
	
	gearScore = floor(gearScore + weaponGS)
	
	local gsR, gsG, gsB = getGSColor(gearScore)
	
		GameTooltip:AddLine("GearScore: "..gearScore, gsR, gsG, gsB )
		GameTooltip:Show()
	ClearInspectPlayer()
		
	
	if (lastQueryTime < GetTime()-5) then
		raidScoreCount = 0
	end
	lastQueryTime = GetTime()
	SetAchievementComparisonUnit("mouseover") 
	frame:RegisterEvent("INSPECT_ACHIEVEMENT_READY");
	raidScoreCount = raidScoreCount + 1
end


----Show item gearScore on the tooltip
function showItemTooltipGS()
	_, iLink = GameTooltip:GetItem()
	if (playerInCombat or not IsEquippableItem(iLink)) then return; end;
	
	local gearScore = 0;
	local weaponGS = 0;
	local totalItems = 0;
	
	local iName, iLink, iRarity, iLevel, iMinLevel, iType, iSubType, iStackCount, iEquipLocation, iTexture, iSellPrice= GetItemInfo(iLink)
	if (iLink ~= nil) then 
	end
	
	local iSlot = 0
	if (itemSlotTable[iEquipLocation]) then 
		iSlot = itemSlotTable[iEquipLocation]["slot"] 
	else
		iSlot = 0
	end
	
	if (iSlot > 0) then
		local itemScore, colorScore = 0,0
		
		itemScore = getItemGS(iLevel, iRarity, iSlot)
		colorScore = itemScore
		
		if (UnitClass("player") == "Hunter") then
			if (iSlot == 16 or iSlot == 17) then
				itemScore = floor(itemScore * 0.3164)
			elseif (iSlot == 18) then
				itemScore = floor(itemScore * 5.3224)
			end
		end
					
		GameTooltip:AddLine("GearScore: "..itemScore, getGSColor((colorScore/charSlot[iSlot])*12.2539))
		GameTooltip:Show()
	end
	

end




--When mouse is moved off of player, tooltip clears
function clearTooltip()
	tooltipCleared = true
end

GameTooltip:HookScript("OnTooltipSetUnit", showTooltipGS)
GameTooltip:HookScript("OnTooltipSetItem", showItemTooltipGS)
GameTooltip:HookScript("OnTooltipCleared", clearTooltip)
